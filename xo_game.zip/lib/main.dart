import 'package:devhub_xo/src/app_root.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(AppRoot());
}

